<?= $this->extend('template/index'); ?>

<?= $this->Section('content');?>
<div class="m-4 pendaftaran">
    <section>
        <h1>Under Development</h1>
    </section>
</div>
<?= $this->endSection(); ?>